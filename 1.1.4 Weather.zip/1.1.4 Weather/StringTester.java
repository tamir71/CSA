
/**
 * Write a description of class StringTester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StringTester
{
    public static void main() {
        String weatherCondition = "1: Tropical Storm";
        System.out.println(WeatherConditionals.getWeatherAdvice(150, "snow"));
    }
}


/**
 * Write a description of class WeatherConditionals here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class WeatherConditionals {
    public static String getWeatherAdvice(int temperature, String description){
        boolean windy = false;
        int temperature;
        if (description.equals("windy")) {
            windy = true;
        }
        if (windy == true || temperature < 31) {
            return "Too windy or cold! Enjoy watching the weather through the window";
        }
        if (description.equals("snow") && temperature > 100) {
            return "What kind of physics-destroying world do you live on?";
        }
            return "It's safe to go outside, " + temperature + " degrees and " + description;
    }
    public static String getHikingAdvice(int temperature, int windchill, int humidity, String description) {
        int temperature;
        int windchill;
        int humidity;
        String description;
        if (temperature > 60) {
            if (description.equals("")) {
                return;
            }
        }
        if () {
            
        }
        if () {
            
        }
        return 
    }
}

